El estudiante debe presentar los siguientes documentos:<br>
- fotocopia de CI<br>
- pago de matriculo<br>
- titulo de bachiller<br>
