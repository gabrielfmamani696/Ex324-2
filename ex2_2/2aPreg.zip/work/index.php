<html>
<body>
	<form action='validaingreso.php' method="GET">
		Usuario<input type="text" name="usuario" value=""/>
		<br/>
		Clave<input type="text" name="clave" value=""/>
		<br/>
		<input type="submit" name="Aceptar" value="Aceptar"/>
	</form>
</body>
</html>