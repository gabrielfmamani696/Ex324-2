<?php
echo "yo soy tu hijo";
?>