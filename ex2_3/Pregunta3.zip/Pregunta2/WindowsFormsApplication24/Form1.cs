﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication24
{
    public partial class Form1 : Form
    {
        int Rm, Gm, Bm;
        int Rmc, Gmc, Bmc, L=10;
        int contador = 0;
        string connectionString = "server=LAPTOP-NAHNRPKV;user=u3242;pwd=123456;database=rgb";
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = string.Empty;
            openFileDialog1.Filter = "Archivos JPG|*.JPG|Archivos BMP|*.bmp";
            openFileDialog1.ShowDialog();
            if (openFileDialog1.FileName != string.Empty)
            {
                Bitmap bmp = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = bmp;
            }
        }


        private void button7_Click(object sender, EventArgs e)
        {
            contador += 1;
            string id = contador.ToString();
            string r = textBox1.Text;
            string g = textBox2.Text;
            string b = textBox3.Text;
            

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string sql = "INSERT INTO col (id, r, g, b) " +
                    "VALUES(@id, @r, @g, @b)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@r", r);
                    cmd.Parameters.AddWithValue("@g", g);
                    cmd.Parameters.AddWithValue("@b", b);
                    cmd.ExecuteNonQuery();
                }
            }
            //importante
            //Response.Redirect(Request.Url.AbsolutePath, false);
            //Context.ApplicationInstance.CompleteRequest();
            Random random = new Random();

            // Generar valores aleatorios para los componentes rojo, verde y azul
            int red = random.Next(256); // Valores de 0 a 255
            int green = random.Next(256);
            int blue = random.Next(256);

            // Crear un color con los valores aleatorios
            Color colorAleatorio = Color.FromArgb(red, green, blue);
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Bitmap bmp2 = new Bitmap(bmp.Width, bmp.Height);
            int Rt = 0, Gt = 0, Bt = 0;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string sql = "SELECT r, g, b FROM col where id = @id";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@id", id); // Asignando el parámetro @id
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Rt = reader.GetInt32(0); // Obtener el valor del segundo campo (r)
                            Gt = reader.GetInt32(1); // Obtener el valor del tercer campo (g)
                            Bt = reader.GetInt32(2); // Obtener el valor del cuarto campo (b)

                            // Hacer algo con los datos recuperados, por ejemplo, imprimirlos
                            //Console.WriteLine($"ID: {id}, R: {r}, G: {g}, B: {b}");
                        }
                    }
                }
            }

            textBox1.Text = Rt.ToString();
            textBox2.Text = Gt.ToString();
            textBox3.Text = Bt.ToString();
            Color c = new Color();
            for (int i = 0; i < bmp.Width - L; i = i + L)
                for (int j = 0; j < bmp.Height - L; j = j + L)
                {
                    Rt = 0; Gt = 0; Bt = 0;
                    for (int o = i; o < i + L; o++)
                        for (int p = j; p < j + L; p++)
                        {
                            c = bmp.GetPixel(o, p);
                            Rt = Rt + c.R;
                            Gt = Gt + c.G;
                            Bt = Bt + c.B;
                        }
                    Rt = Rt / (L * L); Gt = Gt / (L * L); Bt = Bt / (L * L);
                    if (((Rmc - 10 < Rt) && (Rt < Rmc + 10))
                        && ((Gmc - 10 < Gt) && (Gt < Gmc + 10))
                        && ((Bmc - 10 < Bt) && (Bt < Bmc + 10)))
                    {
                        for (int o = i; o < i + L; o++)
                            for (int p = j; p < j + L; p++)
                            {
                                bmp2.SetPixel(o, p, colorAleatorio);
                            }
                    }
                    else
                    {
                        for (int o = i; o < i + L; o++)
                            for (int p = j; p < j + L; p++)
                            {
                                c = bmp.GetPixel(o, p);
                                bmp2.SetPixel(o, p, Color.FromArgb(c.R, c.G, c.B));
                            }
                    }
                }
            pictureBox1.Image = bmp2;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            Color c = new Color();
            c = bmp.GetPixel(e.X, e.Y);
            Rm = c.R;
            Gm = c.G;
            Bm = c.B;
            Rmc = 0; Gmc = 0; Bmc = 0;
            textBox1.Text = c.R.ToString();
            textBox2.Text = c.G.ToString();
            textBox3.Text = c.B.ToString();
            for (int i=e.X-((int)L/2);i<e.X+((int)L/2);i++)
                for (int j = e.Y - ((int)L / 2); j < e.Y + ((int)L / 2); j++)
                {
                    c = bmp.GetPixel(i, j);
                    Rmc = Rmc + c.R; Gmc = Gmc + c.G; Bmc = Bmc + c.B;
                }
            Rmc = (int)Rmc / (L*L);
            Gmc = (int)Gmc / (L*L);
            Bmc = (int)Bmc / (L*L);
            /*
            textBox1.Text = textBox1.Text +" "+Rmc.ToString();
            textBox2.Text = textBox2.Text +" "+Gmc.ToString();
            textBox3.Text = textBox3.Text +" "+Bmc.ToString();
            */
            textBox1.Text = Rmc.ToString();
            textBox2.Text = Gmc.ToString();
            textBox3.Text = Bmc.ToString();
        }

       

        
    }
}
/*
 * borrar la tabla antes de correr el programa


DELETE FROM col;

select * from col;
 * */